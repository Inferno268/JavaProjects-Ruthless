package JLabel;

public class MyJLabel {

}
