import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*ImageIcon image = new ImageIcon("Rocket2.png");
		
		JFrame frame = new JFrame();
		frame.setVisible(true);	//d�ky tomu to vid�
		frame.setTitle("Runtera"); //tittle
		frame.setSize(500,250);	//nastaven� velikosti
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //exit z appky
		frame.setResizable(false); //nem��e� m�nit velikost more 
		frame.setIconImage(image.getImage()); //nastav� favicon
		frame.getContentPane().setBackground(Color.cyan);//m�n� background barvu m��e� d�t i RGB nebo v hexa hodot�ch*/
		
		
		MyFrame mframe = new MyFrame();
		
		
	}

}
