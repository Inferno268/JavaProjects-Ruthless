package Tahov�Boj;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Kostka kostka = new Kostka(10);					//vytvo�en� objektu	(konstruktor)
		Bojovnik bojovnik = new Bojovnik("Imperius",100,20,10,kostka);
		
		System.out.println("�ivot Imperiuse: " + bojovnik.grafickyZivot());	// test GrafickyZivot
		Bojovnik souper = new Bojovnik("Arulus" , 200, 80,10, kostka);
		System.out.println("�ivot Aruluse: " + souper.grafickyZivot());
		souper.utoc(bojovnik);
		
		System.out.println(souper.vratPosledniZpravu());
		System.out.println(bojovnik.vratPosledniZpravu());
		System.out.println("�ivot Imperiuse po �toku: " + bojovnik.grafickyZivot());
		bojovnik.utoc(souper);
		System.out.println(bojovnik.vratPosledniZpravu());
		System.out.println(souper.vratPosledniZpravu());
		System.out.println("�ivot Aruluse po �toku: " + souper.grafickyZivot());
	}

}
